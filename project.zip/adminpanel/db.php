<?php

  $con = new mysqli("localhost", "root", "", "iotnewdb");
?>
